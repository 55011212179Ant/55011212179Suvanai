//
//  ViewController.swift
//  Exam1_55011212179
//
//  Created by Student on 10/10/14.
//  Copyright (c) 2014 Student. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var NameText: UITextField!
    @IBOutlet weak var VolumeText: UITextField!
    @IBOutlet weak var PriceText: UITextField!
    
    @IBAction func TotalButton(sender: AnyObject) {
        
        
    }
    
    
    @IBOutlet weak var TotalText: UITextField!
    @IBOutlet weak var TableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

